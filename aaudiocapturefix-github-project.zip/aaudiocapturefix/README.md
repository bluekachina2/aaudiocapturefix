# AAudio Capture Fix (experimental)

Experimental arm64-v8a Zygisk module intended to alter Spotify's AAudio
capture policy. The native source is based on the files supplied for this
project; it has **not yet been validated on a device**.

## Build with GitHub Actions

1. Create a new GitHub repository named `aaudiocapturefix`.
2. Upload/push the contents of this folder to the repository.
3. Open **Actions** and enable workflows if GitHub asks.
4. Push a commit or select **Build Magisk module** → **Run workflow**.
5. Open the completed workflow run and download the
   `aaudiocapturefix-magisk` artifact.
6. Flash the ZIP from the Magisk app, then reboot.

The workflow downloads the official `zygisk.hpp` header from
[topjohnwu/zygisk-module-sample](https://github.com/topjohnwu/zygisk-module-sample),
builds the native library with Android NDK, and packages the Magisk ZIP.

## Requirements and cautions

- This build targets **arm64-v8a only**.
- Enable Zygisk in Magisk.
- This module injects native code into Spotify. The supplied C++ hook is
  explicitly experimental and untested; a build succeeding does not prove
  the hook works or is safe on your device.
- Keep a recovery/ADB method available to disable or remove the module if
  Spotify crashes or Android becomes unstable.
- The module only changes calls that import
  `AAudioStreamBuilder_setAllowedCapturePolicy`; it cannot guarantee that
  every audio path or recorder will capture Spotify audio.
- Respect Spotify's terms and applicable copyright/privacy rules.

## Repository layout

- `jni/`: C++ source and ndk-build configuration.
- `module/`: files packaged into the flashable Magisk ZIP.
- `.github/workflows/build.yml`: automated GitHub Actions build.
